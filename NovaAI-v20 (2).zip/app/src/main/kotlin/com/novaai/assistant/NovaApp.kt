package com.novaai.assistant

import android.app.Application
import com.novaai.assistant.data.Repo
import com.novaai.assistant.data.Store
import com.novaai.assistant.utils.Perms
import com.novaai.assistant.widget.NovaNotification

class NovaApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        Repo.load()
        com.novaai.assistant.voice.Tts.warm(this)
        com.novaai.assistant.ai.LlmClient.warm()
        com.novaai.assistant.assist.Session.screenShare.value = Store.bool("screen_share")
        NovaNotification.createChannel(this)
        if (Store.notif.value && Perms.overlay(this)) NovaNotification.post(this)
    }
}
