package com.novaai.assistant.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.Typography
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import com.novaai.assistant.R
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Same pair of fonts the LIA app uses: Manrope for text, Instrument Serif for the big friendly words. */
val Manrope = FontFamily(
    Font(R.font.manrope_variable, FontWeight.Normal),
    Font(R.font.manrope_variable, FontWeight.Medium),
    Font(R.font.manrope_variable, FontWeight.SemiBold),
    Font(R.font.manrope_variable, FontWeight.Bold)
)
val Serif = FontFamily(
    Font(R.font.instrument_serif_regular, FontWeight.Normal, FontStyle.Normal),
    Font(R.font.instrument_serif_italic, FontWeight.Normal, FontStyle.Italic)
)

private fun novaTypography(): Typography {
    val d = Typography()
    return d.copy(
        displayLarge = d.displayLarge.copy(fontFamily = Serif), displayMedium = d.displayMedium.copy(fontFamily = Serif),
        displaySmall = d.displaySmall.copy(fontFamily = Serif), headlineLarge = d.headlineLarge.copy(fontFamily = Serif),
        headlineMedium = d.headlineMedium.copy(fontFamily = Serif), headlineSmall = d.headlineSmall.copy(fontFamily = Serif),
        titleLarge = d.titleLarge.copy(fontFamily = Manrope), titleMedium = d.titleMedium.copy(fontFamily = Manrope),
        titleSmall = d.titleSmall.copy(fontFamily = Manrope), bodyLarge = d.bodyLarge.copy(fontFamily = Manrope),
        bodyMedium = d.bodyMedium.copy(fontFamily = Manrope), bodySmall = d.bodySmall.copy(fontFamily = Manrope),
        labelLarge = d.labelLarge.copy(fontFamily = Manrope), labelMedium = d.labelMedium.copy(fontFamily = Manrope),
        labelSmall = d.labelSmall.copy(fontFamily = Manrope)
    )
}

object NovaColors {
    val Navy = Color(0xFF07051A)
    val Navy2 = Color(0xFF14113A)
    val Card = Color(0xCC15122F)
    val Line = Color(0x558B5CFF)
    val Cyan = Color(0xFFB48CFF)      // accent (soft violet)
    val Blue = Color(0xFF6C4DFF)
    val Purple = Color(0xFF8B5CFF)
    val Pink = Color(0xFFE060FF)
    val Orange = Color(0xFFFFB547)    // selected tab, like LIA
    val Green = Color(0xFF2EE6B0)
    val TextDim = Color(0xFF9A93C0)
}

val NovaBg = Brush.verticalGradient(listOf(Color(0xFF1B1040), Color(0xFF0A0720), NovaColors.Navy), endY = 1800f)
val NovaGrad = Brush.linearGradient(listOf(NovaColors.Purple, NovaColors.Pink))

@Composable
fun NovaTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(
        primary = NovaColors.Cyan, secondary = NovaColors.Purple,
        background = NovaColors.Navy, surface = NovaColors.Navy2,
        onBackground = Color.White, onSurface = Color.White
    ),
    typography = novaTypography(),
    content = { ProvideTextStyle(TextStyle(fontFamily = Manrope)) { content() } }
)

@Composable
fun NovaCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable () -> Unit) {
    val base = modifier.clip(RoundedCornerShape(16.dp)).background(NovaColors.Card)
        .border(1.dp, NovaColors.Line, RoundedCornerShape(16.dp))
    Box((if (onClick != null) base.clickable(onClick = onClick) else base).padding(14.dp)) { content() }
}

@Composable
fun Chip(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) = Box(
    modifier.clip(RoundedCornerShape(50)).background(NovaColors.Card)
        .border(1.dp, NovaColors.Line, RoundedCornerShape(50))
        .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp)
) { Text(text, fontSize = 13.sp) }
