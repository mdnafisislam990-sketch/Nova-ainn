package com.novaai.assistant.control

import org.json.JSONObject

/** Every phone action Nova can do. The voice router and the AI both produce these. */
sealed class Cmd {
    data class OpenApp(val name: String) : Cmd()
    data class Call(val who: String) : Cmd()
    object Answer : Cmd()
    object HangUp : Cmd()
    data class Sms(val who: String, val text: String) : Cmd()
    data class WhatsApp(val who: String, val text: String) : Cmd()
    data class Scroll(val next: Boolean) : Cmd()
    data class AutoScroll(val seconds: Int) : Cmd()
    object StopScroll : Cmd()
    data class Nav(val kind: String) : Cmd()      // back home recents notifications quick lock screenshot
    data class Tap(val text: String) : Cmd()
    data class Type(val text: String) : Cmd()
    object Like : Cmd()
    data class Volume(val dir: String) : Cmd()    // up down mute
    data class Media(val kind: String) : Cmd()    // play pause next prev
    data class Torch(val on: Boolean) : Cmd()
    data class Panel(val kind: String) : Cmd()    // wifi bluetooth airplane settings
    object Time : Cmd()
    object StopMic : Cmd()
}

object CmdJson {
    /** The AI may answer with {"action":"call","who":"Rahim"}. Returns null for normal text. */
    fun tryParse(raw: String): Cmd? {
        var s = raw.trim()
        if (s.startsWith("```")) s = s.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        if (!s.startsWith("{")) return null
        val o = runCatching { JSONObject(s) }.getOrNull() ?: return null
        val a = o.optString("action").lowercase()
        fun str(k: String) = o.optString(k).trim()
        return when (a) {
            "open_app" -> str("name").takeIf { it.isNotEmpty() }?.let { Cmd.OpenApp(it) }
            "call" -> str("who").takeIf { it.isNotEmpty() }?.let { Cmd.Call(it) }
            "answer" -> Cmd.Answer
            "hangup", "hang_up", "end_call" -> Cmd.HangUp
            "sms" -> if (str("who").isNotEmpty() && str("text").isNotEmpty()) Cmd.Sms(str("who"), str("text")) else null
            "whatsapp" -> if (str("who").isNotEmpty() && str("text").isNotEmpty()) Cmd.WhatsApp(str("who"), str("text")) else null
            "next" -> Cmd.Scroll(true)
            "previous", "prev" -> Cmd.Scroll(false)
            "auto_scroll" -> Cmd.AutoScroll(o.optInt("seconds", 8).coerceIn(2, 120))
            "stop_scroll" -> Cmd.StopScroll
            "back", "home", "recents", "notifications", "lock", "screenshot" -> Cmd.Nav(a)
            "quick_settings" -> Cmd.Nav("quick")
            "tap" -> str("text").takeIf { it.isNotEmpty() }?.let { Cmd.Tap(it) }
            "type" -> str("text").takeIf { it.isNotEmpty() }?.let { Cmd.Type(it) }
            "like" -> Cmd.Like
            "volume" -> Cmd.Volume(str("dir").ifEmpty { "up" })
            "media" -> Cmd.Media(str("kind").ifEmpty { "play" })
            "torch" -> Cmd.Torch(o.optBoolean("on", true))
            "wifi", "bluetooth", "airplane", "settings" -> Cmd.Panel(a)
            "time" -> Cmd.Time
            else -> null
        }
    }
}
